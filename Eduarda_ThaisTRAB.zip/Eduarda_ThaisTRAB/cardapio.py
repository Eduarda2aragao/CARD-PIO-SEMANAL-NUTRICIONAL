import random
from collections import deque
from itertools import combinations
# =============================================================================
# DIETA INTELIGENTE SEMANAL (SEM CARNE + CÁLCULO CORRETO) - VERSÃO EMAGRECIMENTO(BFS)
# =============================================================================

# --- BASE DE ALIMENTOS (MAIS PROTEÍNAS) ---

#Consumir 2000 kcal mantém o peso.

#Déficit para perder peso – Para emagrecer de forma saudável, recomenda-se um 
#déficit de 300–500 kcal/dia. Assim, 1600 kcal representam um déficit de ~400 kcal em relação ao gasto médio.

CAFE_LANCHE = [
    {"nome": "Ovo", "calorias": 100, "proteina": 10},
    {"nome": "Iogurte", "calorias": 120, "proteina": 8},
    {"nome": "Fruta", "calorias": 80, "proteina": 1},
    {"nome": "Pão integral", "calorias": 140, "proteina": 6},
    {"nome": "Aveia", "calorias": 110, "proteina": 4},
]

ALMOCO_JANTA = [
    {"nome": "Arroz", "calorias": 150, "proteina": 5},
    {"nome": "Feijão", "calorias": 140, "proteina": 8},
    {"nome": "Frango", "calorias": 200, "proteina": 30},
    {"nome": "Peixe", "calorias": 200, "proteina": 25},
    {"nome": "Salada", "calorias": 50, "proteina": 2},
    {"nome": "Grão-de-bico", "calorias": 160, "proteina": 9},
    {"nome": "Lentilha", "calorias": 140, "proteina": 12},
    {"nome": "Tofu", "calorias": 120, "proteina": 12},
    {"nome": "Ovo cozido", "calorias": 155, "proteina": 13},
    {"nome": "Queijo cottage", "calorias": 98, "proteina": 11},
]

PROTEINAS_PRINCIPAIS = ["Frango", "Peixe", "Grão-de-bico", "Lentilha", "Tofu", "Ovo cozido", "Queijo cottage"]

# METAS PARA EMAGRECIMENTO (DÉFICIT CALÓRICO)
META_CALORIAS = 1600
META_PROTEINA = 150

# -----------------------------------------------------------------------------
# PRÉ-CÁLCULO DE COMBINAÇÕES POSSÍVEIS PARA CADA REFEIÇÃO
# -----------------------------------------------------------------------------
def gerar_combinacoes(lista, tamanho):
    """Retorna lista de tuplas (combo, calorias, proteínas, nomes)"""
    combos = []
    for combo in combinations(lista, tamanho):
        cal = sum(a["calorias"] for a in combo)
        prot = sum(a["proteina"] for a in combo)
        nomes = [a["nome"] for a in combo]
        combos.append((combo, cal, prot, nomes))
    return combos

# Gerar todas as possibilidades de cada refeição
combinacoes_cafe = gerar_combinacoes(CAFE_LANCHE, 2)       # 10 combos
combinacoes_lanche = gerar_combinacoes(CAFE_LANCHE, 2)     # 10 combos
combinacoes_almoco = gerar_combinacoes(ALMOCO_JANTA, 3)    # C(13,3)=286 combos
combinacoes_jantar = gerar_combinacoes(ALMOCO_JANTA, 3)    # 286 combos

# -----------------------------------------------------------------------------
# FUNÇÃO DE AVALIAÇÃO (MESMA DO CÓDIGO ORIGINAL)
# -----------------------------------------------------------------------------
def avaliar_dieta(dieta):
    """
    dieta é um dicionário com as chaves: cafe, lanche, almoco, jantar
    Cada valor é uma lista de alimentos (dicionários)
    Retorna o fitness (quanto maior, melhor) e também calorias/proteína totais
    """
    total_calorias = 0
    total_proteina = 0
    todos_alimentos = []
    proteinas_dia = []

    for ref, alimentos in dieta.items():
        for a in alimentos:
            total_calorias += a["calorias"]
            total_proteina += a["proteina"]
            todos_alimentos.append(a["nome"])
        if ref in ["almoco", "jantar"]:
            for a in alimentos:
                if a["nome"] in PROTEINAS_PRINCIPAIS:
                    proteinas_dia.append(a["nome"])

    # Erro absoluto em calorias e proteína
    erro = abs(META_CALORIAS - total_calorias) + abs(META_PROTEINA - total_proteina)

    # Penalidade por repetição de alimentos no mesmo dia
    repeticoes = len(todos_alimentos) - len(set(todos_alimentos))
    penalidade_repeticao = repeticoes * 100

    # Penalidade: duas proteínas principais na mesma refeição
    penalidade_duas_carnes = 0
    for ref in ["almoco", "jantar"]:
        proteinas_ref = [a["nome"] for a in dieta[ref] if a["nome"] in PROTEINAS_PRINCIPAIS]
        if len(proteinas_ref) > 1:
            penalidade_duas_carnes += 200

    # Penalidade: mesma proteína no almoço e jantar
    penalidade_proteina_igual = 0
    if len(set(proteinas_dia)) == 1 and len(proteinas_dia) > 1:
        penalidade_proteina_igual += 150

    fitness = - (erro + penalidade_repeticao + penalidade_duas_carnes + penalidade_proteina_igual)
    return fitness, total_calorias, total_proteina

# -----------------------------------------------------------------------------
# BUSCA EM LARGURA (BFS) PARA ENCONTRAR A MELHOR DIETA DIÁRIA
# -----------------------------------------------------------------------------
def bfs_melhor_dieta():
    """
    Realiza uma busca exaustiva em largura por todas as combinações de refeições.
    Retorna a melhor dieta (dicionário), suas calorias e proteínas.
    """
    # Fila: cada elemento é (índice_da_refeição, estado_atual)
    # índice: 0=cafe, 1=lanche, 2=almoco, 3=jantar
    fila = deque()
    fila.append((0, {}))
    
    melhor_fitness = -float('inf')
    melhor_dieta = None
    melhores_calorias = 0
    melhores_proteinas = 0

    while fila:
        idx, dieta_parcial = fila.popleft()

        if idx == 0:
            for combo, cal, prot, nomes in combinacoes_cafe:
                novo_estado = dieta_parcial.copy()
                novo_estado["cafe"] = combo  # combo é tupla de dicionários
                fila.append((1, novo_estado))
        elif idx == 1:
            for combo, cal, prot, nomes in combinacoes_lanche:
                novo_estado = dieta_parcial.copy()
                novo_estado["lanche"] = combo
                fila.append((2, novo_estado))
        elif idx == 2:
            for combo, cal, prot, nomes in combinacoes_almoco:
                novo_estado = dieta_parcial.copy()
                novo_estado["almoco"] = combo
                fila.append((3, novo_estado))
        else:  # idx == 3
            for combo, cal, prot, nomes in combinacoes_jantar:
                dieta_completa = dieta_parcial.copy()
                dieta_completa["jantar"] = combo
                fitness, total_cal, total_prot = avaliar_dieta(dieta_completa)
                if fitness > melhor_fitness:
                    melhor_fitness = fitness
                    melhor_dieta = dieta_completa
                    melhores_calorias = total_cal
                    melhores_proteinas = total_prot

    return melhor_dieta, melhores_calorias, melhores_proteinas

# -----------------------------------------------------------------------------
# EXECUÇÃO PRINCIPAL
# -----------------------------------------------------------------------------
print("🔍 Executando BFS para encontrar a melhor dieta diária (pode levar alguns segundos)...")
melhor_dia, cal_dia, prot_dia = bfs_melhor_dieta()

# Se quiser variedade na semana, também podemos encontrar as N melhores dietas
# (opcional). Por simplicidade, repetimos o melhor dia para todos os dias.

dias_semana = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"]

print("\n" + "=" * 60)
print("PLANO SEMANAL PARA EMAGRECIMENTO (BFS - BUSCA EM LARGURA)")
print(f"META DIÁRIA: {META_CALORIAS} kcal | PROTEÍNA: {META_PROTEINA} g")
print("=" * 60)

total_semana_cal = 0
total_semana_prot = 0

for dia_nome in dias_semana:
    print(f"\n{dia_nome}:")
    consumo_cal = {}
    total_dia_cal = 0
    total_dia_prot = 0

    for ref, alimentos in melhor_dia.items():
        nomes = [a["nome"] for a in alimentos]
        print(f"  {ref.upper()}: {', '.join(nomes)}")
        for a in alimentos:
            total_dia_cal += a["calorias"]
            total_dia_prot += a["proteina"]
            consumo_cal[a["nome"]] = consumo_cal.get(a["nome"], 0) + a["calorias"]

    print("  ➤ Calorias por alimento:")
    for alimento, cal in consumo_cal.items():
        print(f"     {alimento}: {cal} kcal")
    print(f"  ➤ TOTAL DO DIA: {total_dia_cal} kcal | PROTEÍNA: {total_dia_prot} g")

    total_semana_cal += total_dia_cal
    total_semana_prot += total_dia_prot

print("\n" + "=" * 60)
print(f"RESUMO SEMANAL")
print(f"  TOTAL CALORIAS: {total_semana_cal} kcal")
print(f"  TOTAL PROTEÍNA: {total_semana_prot} g")
print(f"  MÉDIA DIÁRIA CALORIAS: {total_semana_cal / 7:.1f} kcal")
print(f"  MÉDIA DIÁRIA PROTEÍNA: {total_semana_prot / 7:.1f} g")
print("=" * 60)