import random
from collections import deque
from itertools import combinations

# =============================================================================
# DIETA INTELIGENTE SEMANAL PARA GANHO DE MASSA (SUPERÁVIT + ALTA PROTEÍNA) BFS
# =============================================================================

# --- BASE DE ALIMENTOS (MAIS CALÓRICOS E PROTEICOS) ---
#Para ganhar massa muscular, é necessário consumir mais calorias do que se gasta (superávit calórico).

#Um adulto ativo que treina pesado gasta em média entre 
#2200 e 2500 kcal/dia (dependendo do peso, metabolismo e volume de treino).

CAFE_LANCHE = [
    {"nome": "Ovo", "calorias": 100, "proteina": 10},
    {"nome": "Iogurte", "calorias": 120, "proteina": 8},
    {"nome": "Fruta", "calorias": 80, "proteina": 1},
    {"nome": "Pão integral", "calorias": 140, "proteina": 6},
    {"nome": "Aveia", "calorias": 110, "proteina": 4},
    {"nome": "Pasta de amendoim", "calorias": 180, "proteina": 7},
    # Tapioca e ovo mexido foram removidos para reduzir combinações
]

ALMOCO_JANTA = [
    {"nome": "Arroz", "calorias": 150, "proteina": 5},
    {"nome": "Feijão", "calorias": 140, "proteina": 8},
    {"nome": "Frango", "calorias": 200, "proteina": 30},
    {"nome": "Peixe", "calorias": 200, "proteina": 25},
    {"nome": "Salada", "calorias": 50, "proteina": 2},
    {"nome": "Grão-de-bico", "calorias": 160, "proteina": 9},
    # Os demais (lentilha, tofu, ovo cozido, etc.) foram removidos para rapidez
]

PROTEINAS_PRINCIPAIS = ["Frango", "Peixe", "Grão-de-bico"]

# METAS PARA GANHO DE MASSA (SUPERÁVIT CALÓRICO)
META_CALORIAS = 2700
META_PROTEINA = 200

# -----------------------------------------------------------------------------
# PRÉ-CÁLCULO DE COMBINAÇÕES (NÚMERO REDUZIDO)
# -----------------------------------------------------------------------------
def gerar_combinacoes(lista, tamanho):
    combos = []
    for combo in combinations(lista, tamanho):
        cal = sum(a["calorias"] for a in combo)
        prot = sum(a["proteina"] for a in combo)
        nomes = [a["nome"] for a in combo]
        combos.append((combo, cal, prot, nomes))
    return combos

combinacoes_cafe = gerar_combinacoes(CAFE_LANCHE, 2)       # C(6,2)=15 combos
combinacoes_lanche = gerar_combinacoes(CAFE_LANCHE, 2)     # 15 combos
combinacoes_almoco = gerar_combinacoes(ALMOCO_JANTA, 3)    # C(6,3)=20 combos
combinacoes_jantar = gerar_combinacoes(ALMOCO_JANTA, 3)    # 20 combos

# -----------------------------------------------------------------------------
# FUNÇÃO DE AVALIAÇÃO (MESMA LÓGICA ORIGINAL)
# -----------------------------------------------------------------------------
def avaliar_dieta(dieta):
    total_calorias = 0
    total_proteina = 0
    todos_alimentos = []
    proteinas_dia = []

    for ref, alimentos in dieta.items():
        for a in alimentos:
            total_calorias += a["calorias"]
            total_proteina += a["proteina"]
            todos_alimentos.append(a["nome"])
        if ref in ["almoco", "jantar"]:
            for a in alimentos:
                if a["nome"] in PROTEINAS_PRINCIPAIS:
                    proteinas_dia.append(a["nome"])

    erro = abs(META_CALORIAS - total_calorias) + abs(META_PROTEINA - total_proteina)

    repeticoes = len(todos_alimentos) - len(set(todos_alimentos))
    penalidade_repeticao = repeticoes * 100

    penalidade_duas_carnes = 0
    for ref in ["almoco", "jantar"]:
        proteinas_ref = [a["nome"] for a in dieta[ref] if a["nome"] in PROTEINAS_PRINCIPAIS]
        if len(proteinas_ref) > 1:
            penalidade_duas_carnes += 200

    penalidade_proteina_igual = 0
    if len(set(proteinas_dia)) == 1 and len(proteinas_dia) > 1:
        penalidade_proteina_igual += 150

    fitness = - (erro + penalidade_repeticao + penalidade_duas_carnes + penalidade_proteina_igual)
    return fitness, total_calorias, total_proteina

# -----------------------------------------------------------------------------
# BFS (BUSCA EM LARGURA) - VERSÃO RÁPIDA
# -----------------------------------------------------------------------------
def bfs_melhor_dieta():
    fila = deque()
    fila.append((0, {}))  # (índice refeição, dieta_parcial)
    # índice: 0=cafe, 1=lanche, 2=almoco, 3=jantar

    melhor_fitness = -float('inf')
    melhor_dieta = None
    melhores_calorias = 0
    melhores_proteinas = 0

    while fila:
        idx, dieta_parcial = fila.popleft()

        if idx == 0:
            for combo, cal, prot, nomes in combinacoes_cafe:
                novo_estado = dieta_parcial.copy()
                novo_estado["cafe"] = combo
                fila.append((1, novo_estado))
        elif idx == 1:
            for combo, cal, prot, nomes in combinacoes_lanche:
                novo_estado = dieta_parcial.copy()
                novo_estado["lanche"] = combo
                fila.append((2, novo_estado))
        elif idx == 2:
            for combo, cal, prot, nomes in combinacoes_almoco:
                novo_estado = dieta_parcial.copy()
                novo_estado["almoco"] = combo
                fila.append((3, novo_estado))
        else:  # idx == 3
            for combo, cal, prot, nomes in combinacoes_jantar:
                dieta_completa = dieta_parcial.copy()
                dieta_completa["jantar"] = combo
                fitness, total_cal, total_prot = avaliar_dieta(dieta_completa)
                if fitness > melhor_fitness:
                    melhor_fitness = fitness
                    melhor_dieta = dieta_completa
                    melhores_calorias = total_cal
                    melhores_proteinas = total_prot

    return melhor_dieta, melhores_calorias, melhores_proteinas

# -----------------------------------------------------------------------------
# EXECUÇÃO E RELATÓRIO SEMANAL
# -----------------------------------------------------------------------------
print("🔍 Executando BFS rápido (90.000 dietas avaliadas)...")
melhor_dia, cal_dia, prot_dia = bfs_melhor_dieta()

dias_semana = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"]

print("\n" + "=" * 60)
print("PLANO SEMANAL PARA GANHO DE MASSA (BFS RÁPIDO)")
print(f"META DIÁRIA: {META_CALORIAS} kcal | PROTEÍNA: {META_PROTEINA} g")
print("=" * 60)

total_semana_cal = 0
total_semana_prot = 0

for dia_nome in dias_semana:
    print(f"\n{dia_nome}:")
    consumo_cal = {}
    total_dia_cal = 0
    total_dia_prot = 0

    for ref, alimentos in melhor_dia.items():
        nomes = [a["nome"] for a in alimentos]
        print(f"  {ref.upper()}: {', '.join(nomes)}")
        for a in alimentos:
            total_dia_cal += a["calorias"]
            total_dia_prot += a["proteina"]
            consumo_cal[a["nome"]] = consumo_cal.get(a["nome"], 0) + a["calorias"]

    print("  ➤ Calorias por alimento:")
    for alimento, cal in consumo_cal.items():
        print(f"     {alimento}: {cal} kcal")
    print(f"  ➤ TOTAL DO DIA: {total_dia_cal} kcal | PROTEÍNA: {total_dia_prot} g")

    total_semana_cal += total_dia_cal
    total_semana_prot += total_dia_prot

print("\n" + "=" * 60)
print(f"RESUMO SEMANAL")
print(f"  TOTAL CALORIAS: {total_semana_cal} kcal")
print(f"  TOTAL PROTEÍNA: {total_semana_prot} g")
print(f"  MÉDIA DIÁRIA CALORIAS: {total_semana_cal / 7:.1f} kcal")
print(f"  MÉDIA DIÁRIA PROTEÍNA: {total_semana_prot / 7:.1f} g")
print("=" * 60)