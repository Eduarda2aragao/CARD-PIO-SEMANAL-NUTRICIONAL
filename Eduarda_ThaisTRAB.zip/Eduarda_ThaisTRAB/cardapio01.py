import random

# =============================================================================
# DIETA INTELIGENTE SEMANAL PARA EMAGRECIMENTO (ALGORITMO GENÉTICO)
# =============================================================================

# --- BASE DE ALIMENTOS (MESMA DO CÓDIGO ANTERIOR, MAS PODE ADICIONAR MAIS) ---

CAFE_LANCHE = [
    {"nome": "Ovo", "calorias": 100, "proteina": 10},
    {"nome": "Iogurte", "calorias": 120, "proteina": 8},
    {"nome": "Fruta", "calorias": 80, "proteina": 1},
    {"nome": "Pão integral", "calorias": 140, "proteina": 6},
    {"nome": "Aveia", "calorias": 110, "proteina": 4},
]

ALMOCO_JANTA = [
    {"nome": "Arroz", "calorias": 150, "proteina": 5},
    {"nome": "Feijão", "calorias": 140, "proteina": 8},
    {"nome": "Frango", "calorias": 200, "proteina": 30},
    {"nome": "Carne", "calorias": 250, "proteina": 35},
    {"nome": "Peixe", "calorias": 200, "proteina": 25},
    {"nome": "Salada", "calorias": 50, "proteina": 2},
]

PROTEINAS_PRINCIPAIS = ["Frango", "Carne", "Peixe"]

# METAS PARA EMAGRECIMENTO (DÉFICIT CALÓRICO)
META_CALORIAS = 1600   # reduzido de 2000
META_PROTEINA = 150    # mantido alto para preservar músculo

TAMANHO_POPULACAO = 20
MAX_GERACOES = 50
TAXA_MUTACAO = 0.4

# -----------------------------------------------------------------------------
# FUNÇÕES DO ALGORITMO GENÉTICO
# -----------------------------------------------------------------------------

def criar_dieta():
    return {
        "cafe": random.sample(CAFE_LANCHE, 2),
        "lanche": random.sample(CAFE_LANCHE, 2),
        "almoco": random.sample(ALMOCO_JANTA, 3),
        "jantar": random.sample(ALMOCO_JANTA, 3)
    }

def criar_semana():
    return [criar_dieta() for _ in range(7)]

def calcular_fitness(semana):
    fitness_total = 0
    proteinas_semana = []

    for dia in semana:
        total_calorias = 0
        total_proteina = 0
        todos_alimentos = []

        for refeicao in dia.values():
            for alimento in refeicao:
                total_calorias += alimento["calorias"]
                total_proteina += alimento["proteina"]
                todos_alimentos.append(alimento["nome"])

        erro = abs(META_CALORIAS - total_calorias) + abs(META_PROTEINA - total_proteina)

        repeticoes = len(todos_alimentos) - len(set(todos_alimentos))
        penalidade_repeticao = repeticoes * 100

        proteinas_dia = []
        for ref in ["almoco", "jantar"]:
            for a in dia[ref]:
                if a["nome"] in PROTEINAS_PRINCIPAIS:
                    proteinas_dia.append(a["nome"])
        proteinas_semana.append(proteinas_dia)

        penalidade_duas_carnes = 0
        for ref in ["almoco", "jantar"]:
            proteinas_ref = [a["nome"] for a in dia[ref] if a["nome"] in PROTEINAS_PRINCIPAIS]
            if len(proteinas_ref) > 1:
                penalidade_duas_carnes += 200

        penalidade_proteina_igual = 0
        if any(p in proteinas_dia for p in PROTEINAS_PRINCIPAIS):
            if len(set(proteinas_dia)) == 1 and len(proteinas_dia) > 1:
                penalidade_proteina_igual += 150

        fitness_total -= (erro + penalidade_repeticao + penalidade_duas_carnes + penalidade_proteina_igual)

    # Penalidade semanal: mesma proteína em dias consecutivos
    for i in range(len(proteinas_semana) - 1):
        for p in proteinas_semana[i]:
            if p in proteinas_semana[i + 1]:
                fitness_total -= 300

    return fitness_total

def cruzar(p1, p2):
    filho = []
    for i in range(len(p1)):
        filho.append(random.choice([p1[i], p2[i]]))
    return filho

def mutar(semana):
    if random.random() < TAXA_MUTACAO:
        semana[random.randint(0, 6)] = criar_dieta()
    return semana

# -----------------------------------------------------------------------------
# EVOLUÇÃO
# -----------------------------------------------------------------------------
populacao = [criar_semana() for _ in range(TAMANHO_POPULACAO)]

print("=" * 60)
print("BUSCANDO PLANO SEMANAL PARA EMAGRECIMENTO (AG)...")
print(f"META DIÁRIA: {META_CALORIAS} kcal | PROTEÍNA: {META_PROTEINA} g")
print("=" * 60)

for g in range(MAX_GERACOES):
    populacao.sort(key=calcular_fitness, reverse=True)
    melhor = populacao[0]
    print(f"Geração {g} | Fitness: {calcular_fitness(melhor)}")
    nova = populacao[:4]
    while len(nova) < TAMANHO_POPULACAO:
        p1, p2 = random.sample(populacao[:10], 2)
        filho = cruzar(p1, p2)
        filho = mutar(filho)
        nova.append(filho)
    populacao = nova

# -----------------------------------------------------------------------------
# RESULTADO FINAL COM CÁLCULO DE CALORIAS E PROTEÍNAS
# -----------------------------------------------------------------------------
melhor = populacao[0]
dias_semana = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"]

print("\n" + "=" * 60)
print("PLANO SEMANAL PARA EMAGRECIMENTO (ALGORITMO GENÉTICO)")
print(f"META DIÁRIA: {META_CALORIAS} kcal | PROTEÍNA: {META_PROTEINA} g")
print("=" * 60)

total_semana_cal = 0
total_semana_prot = 0

for i, dia in enumerate(melhor):
    print(f"\n{dias_semana[i]}:")
    consumo_cal = {}
    total_dia_cal = 0
    total_dia_prot = 0

    for ref, alimentos in dia.items():
        nomes = [a["nome"] for a in alimentos]
        print(f"  {ref.upper()}: {', '.join(nomes)}")
        for a in alimentos:
            total_dia_cal += a["calorias"]
            total_dia_prot += a["proteina"]
            consumo_cal[a["nome"]] = consumo_cal.get(a["nome"], 0) + a["calorias"]

    print("  ➤ Calorias por alimento:")
    for alimento, cal in consumo_cal.items():
        print(f"     {alimento}: {cal} kcal")
    print(f"  ➤ TOTAL DO DIA: {total_dia_cal} kcal | PROTEÍNA: {total_dia_prot} g")

    total_semana_cal += total_dia_cal
    total_semana_prot += total_dia_prot

print("\n" + "=" * 60)
print("RESUMO SEMANAL")
print(f"  TOTAL CALORIAS: {total_semana_cal} kcal")
print(f"  TOTAL PROTEÍNA: {total_semana_prot} g")
print(f"  MÉDIA DIÁRIA CALORIAS: {total_semana_cal / 7:.1f} kcal")
print(f"  MÉDIA DIÁRIA PROTEÍNA: {total_semana_prot / 7:.1f} g")
print("=" * 60)